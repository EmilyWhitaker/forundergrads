# snow_light
northern snow and light comparisons 
